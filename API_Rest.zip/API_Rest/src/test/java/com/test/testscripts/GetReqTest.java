package com.test.testscripts;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetReqTest {

	@Test
	
	  public void getTest() { System.out.println("sdfh"); Response resp =
	  RestAssured.get("http://dummy.restapiexample.com/api/v1/employees");
	  
	  System.out.println(resp.getHeaders());
	  System.out.println(resp.getBody().prettyPrint());
	  System.out.println(resp.getStatusCode());
	  System.out.println(resp.getContentType());
	  System.out.println(resp.getTime());
	  
	  }
	 
	@Test
	public void postTest() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", "Lakshmi Patnala");
		jsonObject.put("salary", "50000");
		jsonObject.put("age", 40);

		RequestSpecification reqSpec = given();
		reqSpec.contentType(ContentType.JSON);
		reqSpec.body(jsonObject.toJSONString());
		

		Response resp1 = reqSpec.post("http://dummy.restapiexample.com/api/v1/create");
		System.out.println(resp1.getBody().prettyPrint());

	}
}
