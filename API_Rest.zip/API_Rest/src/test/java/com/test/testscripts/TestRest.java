package com.test.testscripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.rest.genericlib.ApiMethods;
import com.rest.genericlib.BaseLibrary;

import io.restassured.response.Response;

public class TestRest extends BaseLibrary {

	@Test
	public void getTest() {
		Response res = ApiMethods.executeRequest("getOneEmployee", REQ_PARA_FILE_PATH, REQ_PARA_SHEET);
		System.out.println(res.prettyPrint());

	}

	public void postTest() throws IOException {

		Response res = ApiMethods.executeRequest("createEmployee", REQ_PARA_FILE_PATH, REQ_PARA_SHEET);

	}

}
