package com.test.testscripts;

import java.io.FileInputStream;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;


import io.restassured.http.ContentType;
import io.restassured.internal.util.IOUtils;

public class PostWithJsonFile {
	
	@Test
	public void postTest()
	{
		
		try
		{
			FileInputStream fis=new FileInputStream(".src/test/resources/data/data.json");
			given().contentType(ContentType.JSON).and().body(IOUtils.toByteArray(fis))
			.when().post("http://dummy.restapiexample.com/create").then().log().all().assertThat()
			.statusCode(201).contentType(ContentType.JSON);
			
			
		}
		catch(Exception ex)
		{
			
		}
	}

}
