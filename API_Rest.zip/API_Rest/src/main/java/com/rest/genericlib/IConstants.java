package com.rest.genericlib;

public interface IConstants {

	String USER_DIR = System.getProperty("user.dir");
	String BASE_URI = "http://dummy.restapiexample.com/api/v1";
	String REQ_PARA_FILE_PATH = "USER_DIR" + "\\src\\main\\resources\\exceldata\\myparameters.xlsx";
	String REQ_PARA_SHEET = "Sheet1";
}
