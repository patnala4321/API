package com.rest.genericlib;

public class GetReq {

}
