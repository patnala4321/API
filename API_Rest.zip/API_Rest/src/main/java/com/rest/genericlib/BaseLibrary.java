package com.rest.genericlib;

import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import static io.restassured.RestAssured.*;



public class BaseLibrary implements IConstants {

	public static ExtentReporter extentReports;
	public static ExtentTest extentTest;
	public static ExtentHtmlReporter extenthtmlReporter;
	public String testCaseName;

	@BeforeSuite
	public void config() {

		baseURI = BASE_URI;
		// port=4444;
		// given().auth().basic(username,password);

	}

}
