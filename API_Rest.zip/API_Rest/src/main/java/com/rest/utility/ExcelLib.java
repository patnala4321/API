package com.rest.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.LinkedHashMap;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.rest.genericlib.IConstants;

public class ExcelLib {

	public static LinkedHashMap getRequestedParameters(String testCaseName, String ePath, String sheetName)

	{

		LinkedHashMap apiReqData = new LinkedHashMap();
		try {

			FileInputStream fis = new FileInputStream(ePath);
			System.out.println(fis + "  sfd");
			Workbook wb = WorkbookFactory.create(fis);
			
			Sheet sheet = wb.getSheet(sheetName);

			int numOfRows = sheet.getPhysicalNumberOfRows();

			int row = 0;
			for (int i = 0; i < numOfRows; i++) {
				System.out.println(sheet.getRow(i).getCell(1).getStringCellValue());
				if (sheet.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase(testCaseName)) {

					for (int j = 2; j < sheet.getRow(i).getPhysicalNumberOfCells(); j++) {

						apiReqData.put(sheet.getRow(1).getCell(j).getStringCellValue(),
								sheet.getRow(i).getCell(j).getStringCellValue());

					}
					break;

				}

			}

		} catch (FileNotFoundException e) {

		}

		catch (Exception e) {

		}

		return apiReqData;
	}

	public static void main(String[] args) {

		System.out.println(
				getRequestedParameters("getAllEmployees", IConstants.REQ_PARA_FILE_PATH, IConstants.REQ_PARA_SHEET));

	}

}